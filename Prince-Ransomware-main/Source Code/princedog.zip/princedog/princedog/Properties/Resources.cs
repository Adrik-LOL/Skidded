﻿// Decompiled with JetBrains decompiler
// Type: ConsoleApp2.Properties.Resources
// Assembly: ConsoleApp2, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D0F3369D-E1F4-44A5-99AD-1CAAAC4FE243
// Assembly location: C:\Users\adria\Desktop\💀\Skidded\Prince-Ransomware-main\princedog.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace ConsoleApp2.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) ConsoleApp2.Properties.Resources.resourceMan, (object) null))
          ConsoleApp2.Properties.Resources.resourceMan = new ResourceManager("ConsoleApp2.Properties.Resources", typeof (ConsoleApp2.Properties.Resources).Assembly);
        return ConsoleApp2.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => ConsoleApp2.Properties.Resources.resourceCulture;
      set => ConsoleApp2.Properties.Resources.resourceCulture = value;
    }

    internal static byte[] wallpaper_jpg
    {
      get
      {
        return (byte[]) ConsoleApp2.Properties.Resources.ResourceManager.GetObject(nameof (wallpaper_jpg), ConsoleApp2.Properties.Resources.resourceCulture);
      }
    }
  }
}
