﻿// Decompiled with JetBrains decompiler
// Type: ConsoleApp2.CenterScreen
// Assembly: ConsoleApp2, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D0F3369D-E1F4-44A5-99AD-1CAAAC4FE243
// Assembly location: C:\Users\adria\Desktop\💀\Skidded\Prince-Ransomware-main\princedog.exe

using System.IO;
using System.Runtime.InteropServices;
using System.Text;

#nullable disable
namespace ConsoleApp2
{
  internal class CenterScreen
  {
    [DllImport("user32.dll")]
    public static extern int SystemParametersInfo(
      CenterScreen.UAction uAction,
      int uParam,
      StringBuilder lpvParam,
      int fuWinIni);

    public static string GetBackgroud()
    {
      StringBuilder lpvParam = new StringBuilder(300);
      CenterScreen.SystemParametersInfo(CenterScreen.UAction.SPI_GETDESKWALLPAPER, 300, lpvParam, 0);
      return lpvParam.ToString();
    }

    public static int SetBackgroud(string fileName)
    {
      int num = 0;
      if (File.Exists(fileName))
        num = CenterScreen.SystemParametersInfo(CenterScreen.UAction.SPI_SETDESKWALLPAPER, 0, new StringBuilder(fileName), 2);
      return num;
    }

    public enum UAction
    {
      SPI_SETDESKWALLPAPER = 20, // 0x00000014
      SPI_GETDESKWALLPAPER = 115, // 0x00000073
    }
  }
}
